package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RefereeRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;

import domain.MessageBox;
import domain.Note;
import domain.Profile;
import domain.Referee;
import domain.Report;

@Service
@Transactional
public class RefereeService {
	
	@Autowired
	private RefereeRepository refereeRepository;
	@Autowired
	private UserAccountService uaS;
	@Autowired
	private ProfileService ps;
	@Autowired
	private MessageBoxService	mbs;
	@Autowired
	private ActorService actorservice;
	
	@Autowired
	private UserAccountRepository  uar;
	@Autowired
	private NoteService ns;
	@Autowired
	private ReportService rs; 

	
	public Referee create(){
		Referee c = new Referee();
		
        Collection<Authority> authorities = new ArrayList<Authority>();
		Authority cust = new Authority();
        cust.setAuthority(Authority.REFEREE);
	    authorities.add(cust);
	    
		
		UserAccount ua = new UserAccount();
		ua.setUsername(null);
		ua.setPassword(null);
		ua.setAuthorities(authorities);
		
		c.setUserAccount(ua);
		
		c.setIsBanned(false);
		c.setIsSuspicious(false);
		
		return c;
	}
	public Collection<Referee> findAll(){
		return refereeRepository.findAll();
	}
	
	public Referee findOne(int refereeId){
		return refereeRepository.findOne(refereeId);
	}
	
	public Referee save(Referee referee){
		if(referee.getUserAccount().getId()==0){
			UserAccount ua = this.uaS.save(referee.getUserAccount());
			referee.setUserAccount(ua);
		}
		Collection<Profile> newProfileList = new ArrayList<Profile>();
		Profile nuevo;
		Collection<Profile> perfiles = referee.getProfiles();
		for(Profile f : perfiles){
			if(f.getId() == 0){
					nuevo = this.ps.save(f);
					
				
			} else {
					nuevo = f;
			}				newProfileList.add(nuevo);

		}
		referee.setProfiles(newProfileList);
		
		Md5PasswordEncoder encoder;
		encoder = new Md5PasswordEncoder();
		String hash;
		hash = encoder.encodePassword(referee.getUserAccount().getPassword(), null);
		referee.getUserAccount().setPassword(hash);
		System.out.println(referee.getUserAccount().getPassword());
		
		//CAJAS//////
				if (referee.getMessageBoxes().isEmpty() || referee.getMessageBoxes() == null) {
					final MessageBox in2 = this.actorservice.createNewMessageBox("user", "in box");
					final MessageBox out2 = this.actorservice.createNewMessageBox("user", "out box");
					final MessageBox trash2 = this.actorservice.createNewMessageBox("user", "trash box");
					final MessageBox spam2 = this.actorservice.createNewMessageBox("user", "spam box");

					final MessageBox in = this.mbs.saveToRemote(in2, referee);
					final MessageBox out = this.mbs.saveToRemote(out2, referee);
					final MessageBox trash = this.mbs.saveToRemote(trash2, referee);
					final MessageBox spam = this.mbs.saveToRemote(spam2, referee);

					final Collection<MessageBox> msboxes = new ArrayList<MessageBox>();
					msboxes.add(in);
					msboxes.add(out);
					msboxes.add(trash);
					msboxes.add(spam);

					referee.setMessageBoxes(msboxes);
				}

				//CAJAS///////
		
		return refereeRepository.save(referee);
	}
	
	public void delete(Referee referee){
		refereeRepository.delete(referee);
	}
	public Note createNoteInReport(final Note n, final Report r) {
		final Referee actual = this.uar.getRefereeByUserAccount(LoginService.getPrincipal().getUsername());
		Assert.isTrue(!actual.getIsBanned());
		Assert.isTrue(r.getReferee().equals(actual));

		final Collection<Note> x = r.getNotes();
		x.add(n);

		r.setNotes(x);

		final Note result = this.ns.save(n);
		this.rs.save(r);

		return result;

	}
}
