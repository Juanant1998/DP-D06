/*
 * AdministratorController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import repositories.AdministratorRepository;
import repositories.ApplicationRepository;
import repositories.CustomerRepository;
import repositories.FixUpTaskRepository;
import repositories.HandyWorkerRepository;
import repositories.ReportRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.ActorService;
import services.AdministratorService;
import services.CategoryService;
import services.EndorsementService;
import services.RefereeService;
import services.SystemConfigService;
import services.WarrantyService;
import domain.Administrator;
import domain.Customer;
import domain.HandyWorker;

@Controller
@RequestMapping("/administrator")
public class AdministratorController extends AbstractController {

	@Autowired
	private AdministratorRepository	administratorRepository;
	@Autowired
	private SystemConfigService		scs;
	@Autowired
	private WarrantyService			warrantyService;
	@Autowired
	private CategoryService			categoryService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private FixUpTaskRepository		futs;
	@Autowired
	private ApplicationRepository	as;
	@Autowired
	private HandyWorkerRepository	hs;
	@Autowired
	private CustomerRepository		cs;
	@Autowired
	private RefereeService			rs;
	@Autowired
	private ReportRepository		rp;
	@Autowired
	private EndorsementService		es;

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private UserAccountRepository	userAccountRepository;


	// Constructors -----------------------------------------------------------

	public AdministratorController() {
		super();
	}

	// Action-1 ---------------------------------------------------------------		

	@RequestMapping(value = "/action-1", method = RequestMethod.GET)
	public ModelAndView action1Get() {
		ModelAndView result;

		result = new ModelAndView("administrator/action-1");

		return result;
	}

	// Action-2 ---------------------------------------------------------------

	@RequestMapping("/action-2")
	public ModelAndView action2() {
		ModelAndView result;

		result = new ModelAndView("administrator/action-2");

		return result;
	}

	@RequestMapping("/information")
	public ModelAndView information() {
		ModelAndView result;

		result = new ModelAndView("administrator/information");

		final Integer min1 = this.futs.minApplicationsByFixUpTasks();
		final Integer max1 = this.futs.maxApplicationsByFixUpTasks();
		final Double avg1 = this.futs.averageApplicationsByFixUpTasks();
		final Integer d1 = this.futs.desviationApplicationsByFixUpTasks();

		final Integer min2 = this.cs.minFixUpTaskByCustomer();
		final Integer max2 = this.cs.maxFixUpTaskByCustomer();
		final Double avg2 = this.cs.averageFixUpTaskByCustomer();
		final Integer d2 = this.cs.deviationFixUpTaskByCustomer();

		final Integer min3 = this.futs.minMaximunPriceByFixUpTasks();
		final Integer max3 = this.futs.maxAMaximunPriceByFixUpTasks();
		final Double avg3 = this.futs.averageMaximunPriceByFixUpTasks();
		final Integer d3 = this.futs.desviationMaximumPriceByFixUpTasks();

		final Integer min4 = this.as.minOfferedPriceByFixUpTasks();
		final Integer max4 = this.as.maxOfferedPriceByFixUpTasks();
		final Double avg4 = this.as.averageOfferedPriceByFixUpTasks();
		final Integer d4 = this.as.desviationOfferedPriceByFixUpTasks();

		final Double rpending = this.as.ratioPendingAplications();

		final Double raccepted = this.as.ratioAcceptedAplications();

		final Double rrejected = this.as.ratioRejectedAplications();

		final Double relapsed = this.as.ratioPendingApplicationsSpiret();

		final Collection<Customer> c9 = this.cs.tenPersentMoreFixUpTasks();

		final Collection<HandyWorker> c10 = this.hs.tenPercentMoreAcceptedApplications();

		result.addObject("min1", min1);
		result.addObject("max1", max1);
		result.addObject("avg1", avg1);
		result.addObject("d1", d1);

		result.addObject("min2", min2);
		result.addObject("max2", max2);
		result.addObject("avg2", avg2);
		result.addObject("d2", d2);

		result.addObject("min3", min3);
		result.addObject("max3", max3);
		result.addObject("avg3", avg3);
		result.addObject("d3", d3);

		result.addObject("min4", min4);
		result.addObject("max4", max4);
		result.addObject("avg4", avg4);
		result.addObject("d4", d4);

		result.addObject("rpending", rpending);
		result.addObject("raccepted", raccepted);
		result.addObject("rrejected", rrejected);
		result.addObject("relapsed", relapsed);

		result.addObject("c9", c9);
		result.addObject("c10", c10);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create")
	public ModelAndView create() {
		ModelAndView result;
		Administrator administrator;

		administrator = this.administratorService.create();
		result = this.createEditModelAndView(administrator);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Administrator administrator;

		final UserAccount uA = LoginService.getPrincipal();
		administrator = this.userAccountRepository.getAdministratorByUserAccount(uA.getUsername());
		Assert.notNull(administrator);

		result = this.createEditModelAndView(administrator);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	// Save ---------------------------------------------------------------	

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Administrator administrator, final BindingResult binding) {
		ModelAndView result;
		System.out.println(administrator.getAddress());
		System.out.println(administrator.getId());

		final Collection<Authority> authorities = new ArrayList<Authority>();

		final Authority cust = new Authority();
		//System.out.println(cust);
		cust.setAuthority(Authority.ADMIN);

		authorities.add(cust);
		//System.out.println(authorities);
		administrator.getUserAccount().setAuthorities(authorities);
		System.out.println(administrator.getUserAccount().getAuthorities());

		System.out.println(administrator.getEmail());
		System.out.println(administrator.getMessageBoxes());

		System.out.println(administrator.getProfiles());
		System.out.println(administrator.getAddress());

		System.out.println("antes del if");
		if (binding.hasErrors()) {
			System.out.println("binding");
			result = this.createEditModelAndView(administrator);
			System.out.println("despues del editmodelandview");
		} else
			try {
				System.out.println("try");
				this.administratorService.save(administrator);
				result = new ModelAndView("redirect:/welcome/index.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(administrator, "administrator.commit.error");
			}
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	protected ModelAndView createEditModelAndView(final Administrator administrator) {
		ModelAndView result;

		result = this.createEditModelAndView(administrator, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Administrator administrator, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("administrator/edit");
		result.addObject("administrator", administrator);

		result.addObject("message", messageCode);

		return result;
	}

}
