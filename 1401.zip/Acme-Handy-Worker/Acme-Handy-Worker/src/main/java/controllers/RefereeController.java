
package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.RefereeService;
import services.SystemConfigService;
import domain.Referee;

@Controller
@RequestMapping("/referee")
public class RefereeController extends AbstractController {

	@Autowired
	private SystemConfigService		scs;
	@Autowired
	private RefereeService			refereeService;

	@Autowired
	private UserAccountRepository	userAccountRepository;


	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create")
	public ModelAndView create() {
		ModelAndView result;
		Referee referee;

		referee = this.refereeService.create();
		result = this.createEditModelAndView(referee);

		return result;
	}

	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Referee referee;

		final UserAccount uA = LoginService.getPrincipal();
		referee = this.userAccountRepository.getRefereeByUserAccount(uA.getUsername());
		Assert.notNull(referee);

		result = this.createEditModelAndView(referee);

		return result;
	}

	// Save ---------------------------------------------------------------	

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Referee referee, final BindingResult binding) {
		ModelAndView result;
		System.out.println(referee.getAddress());
		System.out.println(referee.getId());

		final Collection<Authority> authorities = new ArrayList<Authority>();

		final Authority cust = new Authority();
		//System.out.println(cust);
		cust.setAuthority(Authority.REFEREE);

		authorities.add(cust);
		//System.out.println(authorities);
		referee.getUserAccount().setAuthorities(authorities);
		System.out.println(referee.getUserAccount().getAuthorities());

		System.out.println(referee.getEmail());
		System.out.println(referee.getMessageBoxes());

		System.out.println(referee.getProfiles());
		System.out.println(referee.getAddress());

		System.out.println("antes del if");
		if (binding.hasErrors()) {
			System.out.println("binding");
			result = this.createEditModelAndView(referee);
			System.out.println("despues del editmodelandview");
		} else
			try {
				System.out.println("try");
				this.refereeService.save(referee);
				result = new ModelAndView("redirect:/welcome/index.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(referee, "referee.commit.error");
			}

		return result;
	}

	protected ModelAndView createEditModelAndView(final Referee referee) {
		ModelAndView result;

		result = this.createEditModelAndView(referee, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Referee referee, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("referee/edit");
		result.addObject("referee", referee);

		result.addObject("message", messageCode);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

}
