package converters;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import repositories.ProfileRepository;


import domain.Profile;

@Component
@Transactional
public class StringToProfileConverter implements Converter<String, Profile>{
	
	
	@Autowired
	private ProfileRepository profileRepository;
	
	@Override
	public Profile convert(String text) {
		Profile result;
		
		try {
			if (StringUtils.isEmpty(text)){
				result = null;
			}else{
				String [] array= text.split(";");
				Profile f = new Profile();
				f.setSocialNetwork(array[0]);
				f.setNick(array[1]);
				f.setSnLink(array[2]);
				
				for (Profile comp: profileRepository.findAll()){
					if(comp.getNick().equals( f.getNick()) && comp.getSnLink().equals( f.getSnLink())){
						f = comp;
						break;
					}
				}
				result = f;
			}
		} catch (Throwable oops){
			throw new IllegalArgumentException(oops);
			
		}
		
		return result;
	}


}
