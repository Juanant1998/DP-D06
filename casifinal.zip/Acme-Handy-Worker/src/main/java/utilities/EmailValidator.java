package utilities;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator {

  private final Pattern    pattern;
  private Matcher        matcher;

  private static final String  EMAIL_PATTERN    = "[a-z0-9.]+@[a-z0-9.]+|[a-zA-Z0-9]+[<]+[a-zA-Z0-9]+@+[a-zA-Z0-9.-]+[>]{1,}";
  private static final String  ADMIN_EMAIL_PATTERN  = "[a-z0-9.]+@$|[a-zA-Z0-9]+[<]+[a-zA-Z0-9]+@+[>]{1,}$";


  public EmailValidator(Boolean admin) {
    if (admin == true)
      this.pattern = Pattern.compile(EmailValidator.ADMIN_EMAIL_PATTERN);
    else
      this.pattern = Pattern.compile(EmailValidator.EMAIL_PATTERN);
  }

  /**
   * Validate hex with regular expression
   * 
   * @param hex
   *            hex for validation
   * @return true valid hex, false invalid hex
   */
  public boolean validate(final String hex) {

    this.matcher = this.pattern.matcher(hex);
    return this.matcher.matches();

  }

}