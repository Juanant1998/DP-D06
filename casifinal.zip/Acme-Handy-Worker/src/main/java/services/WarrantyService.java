
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import repositories.WarrantyRepository;
import domain.Warranty;

@Service
@Transactional
public class WarrantyService {

	@Autowired
	private WarrantyRepository	warrantyRepository;


	public Warranty create() {
		return new Warranty();
	}

	public Collection<Warranty> findAll() {
		return this.warrantyRepository.findAll();
	}

	public Warranty findOne(final int warrantyId) {
		return this.warrantyRepository.findOne(warrantyId);
	}

	public Warranty save(final Warranty warranty) {
		return this.warrantyRepository.save(warranty);
	}

	public void delete(final Warranty warranty) {
		this.warrantyRepository.delete(warranty);
	}

	public Collection<Warranty> findAllFinalMode() {
		final Collection<Warranty> warranties = this.warrantyRepository.findAll();
		final Collection<Warranty> result = new ArrayList<Warranty>();
		for (final Warranty x : warranties)
			if (x.isDraftMode() == false)
				result.add(x);

		return warranties;
	}

}
