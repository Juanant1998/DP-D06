
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.AdministratorService;
import services.WarrantyService;
import domain.Warranty;

@Controller
@RequestMapping("/warranty/administrator")
public class WarrantyAdministratorController extends AbstractController {

	@Autowired
	private WarrantyService			warrantyService;
	private AdministratorService	administratorService;


	public WarrantyAdministratorController() {
		super();
	}
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		final Collection<Warranty> warranties = this.warrantyService.findAll();
		result = new ModelAndView("warranty/list");
		result.addObject("warranties", warranties);
		result.addObject("requestURI", "/warranty/administrator/list.do");

		return result;
	}
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Warranty warranty;
		// cambio  de warrantyService.create() a 
		warranty = this.warrantyService.create();
		result = this.createEditModelAndView(warranty);
		return result;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int warrantyId) {
		ModelAndView result;
		Warranty warranty;
		warranty = this.warrantyService.findOne(warrantyId);
		Assert.isTrue(warranty.isDraftMode());
		Assert.notNull(warranty);
		result = this.createEditModelAndView(warranty);
		return result;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Warranty warranty, final BindingResult binding) {
		ModelAndView result;
		System.out.println(warranty.getApplicableLaws());
		System.out.println(warranty.getTitle());
		System.out.println(warranty.getTerms());
		System.out.println(warranty.isDraftMode());
		System.out.println("id fuera del try" + warranty.getId());
		if (binding.hasErrors())
			result = this.createEditModelAndView(warranty);
		else
			try {

				System.out.println("dentro del try");
				System.out.println(warranty.getId());
				this.warrantyService.save(warranty);
				System.out.println("pasa el update");
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(warranty, "warranty.commit.error");
			}

		return result;

	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid final Warranty warranty, final BindingResult binding) {
		ModelAndView result;

		try {
			this.warrantyService.delete(warranty);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(warranty, "warranty.commit.error");
		}

		return result;

	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int warrantyId) {
		ModelAndView result;
		Warranty warranty;

		warranty = this.warrantyService.findOne(warrantyId);
		Assert.notNull(warranty);

		result = this.createDisplayModelAndView(warranty);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Warranty warranty) {
		ModelAndView result;

		result = this.createEditModelAndView(warranty, null);
		return result;
	}
	protected ModelAndView createEditModelAndView(final Warranty warranty, final String messageCode) {

		ModelAndView result;
		result = new ModelAndView("warranty/edit");
		result.addObject("warranty", warranty);
		result.addObject("message", messageCode);
		return result;

	}
	protected ModelAndView createDisplayModelAndView(final Warranty c) {
		ModelAndView result;
		result = this.createDisplayModelAndView(c, null);

		return result;
	}

	protected ModelAndView createDisplayModelAndView(final Warranty c, final String messageCode) {
		ModelAndView result;
		result = new ModelAndView("warranty/display");
		result.addObject("warranty", c);

		result.addObject("message", messageCode);

		return result;

	}

}
