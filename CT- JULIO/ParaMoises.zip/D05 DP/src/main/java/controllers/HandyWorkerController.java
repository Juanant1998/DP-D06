package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import domain.HandyWorker;

import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.HandyWorkerService;

@Controller
@RequestMapping("/handyworker")
public class HandyWorkerController extends AbstractController{
	
	@Autowired
	private UserAccountRepository userAccountRepository;
	
	@Autowired
	private HandyWorkerService hwService;
	
	// Create ---------------------------------------------------------------		

		@RequestMapping(value="/create")
		public ModelAndView create() {
			ModelAndView result;
			HandyWorker handyWorker;
			
			handyWorker = this.hwService.create();
			result = this.createEditModelAndView(handyWorker);
			
			return result;
		}
		
	// Edit ---------------------------------------------------------------		

		@RequestMapping(value="/edit", method=RequestMethod.GET)
		public ModelAndView edit() {
			ModelAndView result;
			HandyWorker handyWorker;
			
			UserAccount uA = LoginService.getPrincipal();
			handyWorker = this.userAccountRepository.getHandyByUserAccount(uA.getUsername());
			Assert.notNull(handyWorker);
			
			result = this.createEditModelAndView(handyWorker);
			
			return result;
		}
		
	// Edit Make ---------------------------------------------------------------		

				@RequestMapping(value="/edit_make", method=RequestMethod.GET)
				public ModelAndView editMake() {
					ModelAndView result;
					HandyWorker handyWorker;
					
					UserAccount uA = LoginService.getPrincipal();
					handyWorker = this.userAccountRepository.getHandyByUserAccount(uA.getUsername());
					Assert.notNull(handyWorker);
					
					result = this.createEditMakeModelAndView(handyWorker);
					
					return result;
				}
		


		// Save ---------------------------------------------------------------	
		
		@RequestMapping(value="/edit", method=RequestMethod.POST, params = "save")
		public ModelAndView save(@Valid final HandyWorker handyWorker, final BindingResult binding){
			ModelAndView result;
			System.out.println(handyWorker.getAddress());
			System.out.println(handyWorker.getId());
			
			Collection<Authority> authorities = new ArrayList<Authority>();
			
			Authority cust = new Authority();
			//System.out.println(cust);
			cust.setAuthority(Authority.HANDYWORKER);
			
			authorities.add(cust);
			//System.out.println(authorities);
			handyWorker.getUserAccount().setAuthorities(authorities);
			System.out.println(handyWorker.getUserAccount().getAuthorities());

			System.out.println(handyWorker.getMake());
			System.out.println(handyWorker.getEmail());
			System.out.println(handyWorker.getMessageBoxes());
			
			System.out.println(handyWorker.getProfiles());
			System.out.println(handyWorker.getAddress());
			System.out.println(handyWorker.getCurriculum());

			System.out.println("antes del if");
			if(binding.hasErrors()){
				System.out.println("binding");
				result = this.createEditModelAndView(handyWorker);
				System.out.println("despues del editmodelandview");
			} else{
				try {
					System.out.println("try");
					
					this.hwService.save(handyWorker);
					result = new ModelAndView("redirect:/welcome/index.do");
			
				} catch(Throwable oops){
					result = this.createEditModelAndView(handyWorker, "handyworker.commit.error");
				}
			}
			
			return result;
		}

	
	protected ModelAndView createEditModelAndView(HandyWorker handyWorker) {
		 ModelAndView result;
			
         result = this.createEditModelAndView(handyWorker, null);
			
		 return result;
	}
	
	protected ModelAndView createEditModelAndView(HandyWorker handyWorker, String messageCode) {
        ModelAndView result;
		
		//System.out.println(cust);
		
		//System.out.println(authorities);
		
		//System.out.println(customer.getUserAccount().getAuthorities());
		result = new ModelAndView("handyworker/edit");
		result.addObject("handyworker", handyWorker);
		
		
		result.addObject("message", messageCode);
		
		return result;
	}
	
	//Model and View of Make

	protected ModelAndView createEditMakeModelAndView(HandyWorker handyWorker) {
	 ModelAndView result;
		
     result = this.createEditMakeModelAndView(handyWorker, null);
			
     return result;
	
    }

	protected ModelAndView createEditMakeModelAndView(HandyWorker handyWorker, String messageCode){
			ModelAndView result;

			result = new ModelAndView("handyworker/edit_make");
			result.addObject("handyworker", handyWorker);
			
			
			result.addObject("message", messageCode);
			
			return result;
	}


}

