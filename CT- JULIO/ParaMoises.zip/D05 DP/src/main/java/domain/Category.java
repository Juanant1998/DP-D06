
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
@Access(AccessType.PROPERTY)
public class Category extends DomainEntity {

	private Collection<String>		name;			// notBlank  unique
	private Collection<Category>	descendants;


	@OneToMany
	public Collection<Category> getDescendants() {
		return this.descendants;
	}

	public void setDescendants(final Collection<Category> descendants) {
		this.descendants = descendants;
	}

	@ElementCollection(targetClass = String.class)
	public Collection<String> getName() {
		return this.name;
	}

	public void setName(final Collection<String> name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.name.toString();
	}

}
