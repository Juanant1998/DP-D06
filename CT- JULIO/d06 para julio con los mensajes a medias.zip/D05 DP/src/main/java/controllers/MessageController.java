
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.AdministratorService;
import services.MessageBoxService;
import services.MessageService;
import domain.Message;

@Controller
@RequestMapping("/messages")
public class MessageController extends AbstractController {

	@Autowired
	MessageService			ms;

	@Autowired
	ActorService			as;

	@Autowired
	MessageBoxService		mbs;

	@Autowired
	AdministratorService	ads;


	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int messageBoxId) {

		ModelAndView result;
		final Collection<Message> mes;

		mes = this.as.messagesByMessageBoxName(this.mbs.findOne(messageBoxId).getName());
		result = new ModelAndView("messages/list");

		System.out.println(mes);
		result.addObject("messages", mes);

		result.addObject("requestURI", "/messages/list.do");

		return result;

	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Message message;

		message = this.ms.create();

		result = this.createEditModelAndView(message);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int messageId) {
		ModelAndView result;
		Message message;

		message = this.ms.findOne(messageId);
		Assert.notNull(message);
		result = this.createEditModelAndView(message);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "send")
	public ModelAndView send(@Valid final Message message, final BindingResult binding) {
		ModelAndView result;
		System.out.println("entra en el edit");
		System.out.println("TESTING =================================");
		System.out.println(message.getBody());
		System.out.println(message.getId());
		System.out.println(message.getPriority());
		System.out.println(message.getTags());
		System.out.println(message.getSubject());

		System.out.println(message.getMoment());
		System.out.println("TESTING =================================");

		if (binding.hasErrors()) {
			System.out.println("tiene errores");

			result = this.createEditModelAndView(message);
		} else
			try {
				this.as.sendMessage(message);
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(message, "messages.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "sendToAll")
	public ModelAndView broadcast(@Valid final Message message, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(message);
			System.out.println("el formulario tiene errores");

		} else
			try {
				this.ads.broadcastMessage(message);
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(message, "messages.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Message message, final BindingResult binding) {
		ModelAndView result;

		try {
			this.as.deleteMessage(message);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(message, "messages.commit.error");
		}

		return result;
	}

	protected ModelAndView createEditModelAndView(final Message m) {
		ModelAndView result;
		result = this.createEditModelAndView(m, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Message m, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("messages/edit");
		result.addObject("mesInformation", m);
		System.out.println("llega hasta el editmodelandview");
		result.addObject("mesError", messageCode);

		return result;
	}

}
