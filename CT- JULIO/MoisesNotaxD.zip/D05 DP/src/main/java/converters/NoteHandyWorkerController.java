/*
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.MessageBox;
import domain.Note;

import services.HandyWorkerService;
import services.NoteService;

@Controller
@RequestMapping("/note")
public class NoteHandyWorkerController extends AbstractController {

	@Autowired
	HandyWorkerService	hws;

	@Autowired
	NoteService			ns;


	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView result;
		final Collection<Note> note;

		note = this

		result = new ModelAndView("messageBox/list");

		System.out.println(mBox);
		result.addObject("messageBoxes", mBox);

		result.addObject("requestURI", "/messageBox/list.do");

		return result;

	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Note note, @RequestParam final int reportId, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(note);
		else
			try {
				this.hws.writeCommentOnNote(note, note.getComment());
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(messageBox, "messages.commit.error");
			}

		return result;
	}

}
*/