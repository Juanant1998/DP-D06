package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RefereeRepository;
import security.LoginService;

import domain.Complaint;
import domain.Customer;
import domain.FixUpTask;
import domain.Note;
import domain.Referee;
import domain.Report;
import domain.Warranty;

@Service
@Transactional
public class RefereeService {
	
	@Autowired
	private RefereeRepository refereeRepository;
	
	@Autowired
	private UserAccountService		uas;
	@Autowired
	private ReportService		rs;
	
	@Autowired
	private NoteService ns;
	
	
	public Referee create(){
		return new Referee();	
	}
	public Collection<Referee> findAll(){
		return refereeRepository.findAll();
	}
	
	public Referee findOne(int refereeId){
		return refereeRepository.findOne(refereeId);
	}
	
	public Referee save(Referee referee){
		return refereeRepository.save(referee);
	}
	
	public void delete(Referee referee){
		refereeRepository.delete(referee);
	}
	public Collection<Report> getMyReports() {


		final Referee actual = this.uas.getRefereeByUserAccount(LoginService.getPrincipal());


		System.out.println(actual);
		System.out.println(actual.getIsBanned());
		Assert.isTrue(true);
		final Collection<Report> reports =  rs.findAll();
	 final Collection<Report>   result = new ArrayList<>();
		for (final Report r : reports) {
			if(r.getReferee().equals(actual)){
				result.add(r);
			}
			
		}
		return result;
	}
	public Report updateReport(final Report re) {
Assert.isTrue(re.isDraftMode());
	
		Report result  = rs.save(re);
		

		return result;
	}
public Report createReport(){
	
     Report result = rs.create();
     Assert.isTrue(result.isDraftMode());
     
     return result;
}
public void deleteReport(final Report re){
	Assert.isTrue(re.isDraftMode());
	rs.delete(re);
	
	
}
public Note createNoteInReport(final Note n, final Report r) {
	final Referee actual = this.uas.getRefereeByUserAccount(LoginService.getPrincipal());
	Assert.isTrue(!actual.getIsBanned());
	Assert.isTrue(r.getReferee().equals(actual));

	final Collection<Note> x = r.getNotes();
	x.add(n);

	r.setNotes(x);

	final Note result = this.ns.save(n);
	this.rs.save(r);

	return result;

}
	
}
