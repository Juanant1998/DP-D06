package controllers;

import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Category;
import domain.Finder;
import domain.FixUpTask;
import domain.Warranty;

import services.FinderService;

@Controller
@RequestMapping("/finder/handyworker")
public class FinderHandyWorkerController extends AbstractController {
@Autowired
private FinderService finderService;

public FinderHandyWorkerController(){
	super();
}

@RequestMapping(value="/create", method = RequestMethod.GET)
public ModelAndView create(){
	ModelAndView result;
	Finder finder;
	// cambio  de warrantyService.create() a 
	finder=this.finderService.create();
	result = this.createEditModelAndView(finder);
	return result;
}
@RequestMapping(value="/edit",method=RequestMethod.POST,params="search")
public ModelAndView save(@Valid Finder finder,BindingResult binding){
ModelAndView result;


//ES NECESARIO ENCONTRAR TODAS LAS QUE NO TENGAN UNA ACEPTADA????


 Finder  sq = this.finderService.allFilters(finder);
 final Collection<FixUpTask> col = sq.getFixUpTasks();
result = new ModelAndView("fixuptask/list");

System.out.println(col);
result.addObject("fixuptasks", col);

result.addObject("requestURI", "/fixuptask/handyworker/list.do");

return result;

}
	

	

protected ModelAndView createEditModelAndView(final Finder f) {
	ModelAndView result;
	result = this.createEditModelAndView(f, null);

	return result;
}

protected ModelAndView createEditModelAndView(final Finder f, final String messageCode) {
	ModelAndView result;
	Collection<Finder> finderlist;

	finderlist = this.finderService.findAll();
	if (finderlist.contains(f))
		finderlist.remove(f);

	result = new ModelAndView("finder/edit");
	result.addObject("finder", f);
	result.addObject("list", finderlist);

	result.addObject("message", messageCode);

	return result;
}



}
