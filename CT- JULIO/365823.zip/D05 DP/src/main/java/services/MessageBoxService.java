
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MessageBoxRepository;
import domain.MessageBox;

@Service
@Transactional
public class MessageBoxService {

	@Autowired
	private MessageBoxRepository	messageBoxRepository;


	public MessageBox create() {
		return new MessageBox();
	}
	public Collection<MessageBox> findAll() {
		return this.messageBoxRepository.findAll();
	}

	public MessageBox findOne(final int messageBoxId) {
		return this.messageBoxRepository.findOne(messageBoxId);
	}

	public MessageBox save(final MessageBox messageBox) {
		return this.messageBoxRepository.save(messageBox);
	}

	public void delete(final MessageBox messageBox) {
		Assert.isTrue(!messageBox.isSystemBox() == true);
		this.messageBoxRepository.delete(messageBox);
	}

}
