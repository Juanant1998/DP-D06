
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Message;
import domain.MessageBox;
import domain.Note;
import domain.Report;

import services.HandyWorkerService;
import services.NoteService;
import services.ReportService;

@Controller
@RequestMapping("/note")
public class NoteController extends AbstractController {

	@Autowired
	HandyWorkerService	hws;
	
	@Autowired
	ReportService	rs;

	@Autowired
	NoteService			ns;


	@RequestMapping(value="/create", method = RequestMethod.GET)
	public ModelAndView create(){
		ModelAndView result;
		Note note;

		note = this.ns.create();

		result = this.createEditModelAndView(note);
		return result;
	}
	
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Note note, @RequestParam final int reportId,  final BindingResult binding) {
		ModelAndView result;
		
		Report r = this.rs.findOne(reportId);

		if (binding.hasErrors())
			result = this.createEditModelAndView(note);
		else
			try {
				this.hws.createNoteInReport(note, r);
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(note, "messages.commit.error");
			}

		return result;
	}
	protected ModelAndView createEditModelAndView(final Note n) {
		ModelAndView result;

		result = this.createEditModelAndView(n, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Note n, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("note/edit");
		result.addObject("note", n);

		result.addObject("message", messageCode);

		return result;
	}
}

