package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ActorRepository;
import repositories.MessageBoxRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.MessageBox;

@Service
@Transactional
public class MessageBoxService {
	
	@Autowired
	private MessageBoxRepository messageBoxRepository;
	
	@Autowired
	private ActorRepository actorRepository;
	
	public MessageBox create() {
		
		final MessageBox msgbox = new MessageBox();
		
		msgbox.setSystemBox(false);
		return msgbox;
	}
	
	public Collection<MessageBox> findAll(){
		return messageBoxRepository.findAll();
	}
	
	public MessageBox findOne(int messageBoxId){
		return messageBoxRepository.findOne(messageBoxId);
	}
	
	public MessageBox save(final MessageBox messageBox) {
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);
		MessageBox mb = this.messageBoxRepository.save(messageBox);
		if(!a.getMessageBoxes().contains(messageBox)){
			Collection<MessageBox> mboxes = a.getMessageBoxes();
			mboxes.add(mb);
			a.setMessageBoxes(mboxes);
			Assert.isTrue(a.getMessageBoxes().contains(mb));
		
		}
		return mb;	
		
		
	}

	public void delete(final MessageBox messageBox) {
		Assert.isTrue(!messageBox.isSystemBox() == true);
		this.messageBoxRepository.delete(messageBox);
	}

}
