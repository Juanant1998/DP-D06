package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


import domain.Complaint;


import repositories.ComplaintRepository;

@Component
@Transactional
public class StringToComplaintConverter implements Converter<String,Complaint> {
	@Autowired
	ComplaintRepository	cp;
	
	@Override
	public Complaint convert(final String text) {
		Complaint result;
		 int id;
	
		 
		 try {
				if (StringUtils.isEmpty(text))
					result = null;
				else {
					id = Integer.valueOf(text);
					result = this.cp.findOne(id);
				}
			} catch (final Throwable oops) {
				throw new IllegalArgumentException(oops);
			}
			return result;

		}
		 
		
	}
	

