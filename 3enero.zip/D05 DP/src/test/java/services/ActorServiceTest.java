
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Actor;
import domain.Message;
import domain.MessageBox;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ActorServiceTest extends AbstractTest {

	@Autowired
	private ActorService		actorService;

	@Autowired
	private MessageBoxService	messageBoxService;

	@Autowired
	private MessageService		messageService;


	@Test
	public void testSaveActors() {
		//Actor
		final Collection<Actor> actors = new ArrayList<>();
		final Actor guardando = this.actorService.findOne(super.getEntityId("handyWorker1"));
		this.actorService.save(guardando);
		actors.add(guardando);
		Assert.isTrue(actors.contains(guardando));

	}
	@Test
	public void testDeleteActor() {
		final Actor borrando = this.actorService.findOne(super.getEntityId("handyWorker1"));
		this.actorService.delete(borrando);
		Assert.isNull(this.actorService.findOne(borrando.getId()));
	}
	@Test
	public void findOneOk() {
		final Actor find = this.actorService.findOne(super.getEntityId("handyWorker2"));
		final int findId = find.getId();
		Assert.notNull(this.actorService.findOne(findId));
	}
	@Test
	public void FindAll() {
		Collection<Actor> actors;
		actors = this.actorService.findAll();
		Assert.isTrue(!actors.isEmpty());

	}
	@Test
	public void CreateTest() {
		final Actor create = this.actorService.create();
		Assert.notNull(create);

	}

	@Test
	public void TestActorBanned() {
		final Actor find = this.actorService.findOne(super.getEntityId("handyWorker3"));
		Assert.isTrue(!find.getIsBanned());
	}
	@Test
	public void TestCreateMessageBox() {
		final MessageBox create = this.messageBoxService.create();
		final String username = "paco";
		final String msgboxname = "caja de mensaje";

		create.setName(username + " " + msgboxname);
		create.setSystemBox(false);

		Assert.notNull(create);
	}

	@Test
	public void TestSendMessage() {
		final Message mes = this.messageService.findOne(super.getEntityId("message2"));
		Collection<Actor> recipients = mes.getRecipients();
		Assert.notEmpty(recipients);
		Assert.notNull(mes.getSender());
		final Message m = this.actorService.sendMessage(mes);
		final Actor sender = m.getSender();

		for (final MessageBox mboxSen : sender.getMessageBoxes())
			if (mboxSen.isSystemBox() == true && mboxSen.getName().endsWith("out"))
				Assert.isTrue(mboxSen.getMessages().contains(m));

		recipients = m.getRecipients();

		for (final Actor a : recipients)
			for (final MessageBox mbox : a.getMessageBoxes())
				if (mbox.isSystemBox() == true && mbox.getName().endsWith("in"))
					Assert.isTrue((mbox.getMessages().contains(m)));

	}
	
	 	  
	  @Test
	  public void editMessageBoxTest(){//Try to edit a system box
	  super.authenticate("handyworker1");
	  MessageBox m = this.messageBoxService.findOne(super.getEntityId("pepe22"));
	  MessageBox res = this.actorService.editMessageBox(m);
	  Assert.notNull(this.messageBoxService.findOne(res.getId()));
	  super.authenticate(null);
	  }
	  
	 @Test
	  public void deleteMessageBoxTest(){ //Intenta borrar una caja del sistema
	  super.authenticate("handyworker1");
	  MessageBox m = this.messageBoxService.findOne(super.getEntityId("in1"));
	  this.actorService.deleteMessageBox(m);
	  Assert.notNull(this.actorService.findOne(m.getId()));
	  
	  super.authenticate(null);
	  }
	 

	@Test
	public void editDataTest() {
		final Actor a1 = this.actorService.findOne(super.getEntityId("handyWorker2"));

		final String comprueba = a1.getEmail();

		a1.setEmail("g@gmail.com");

		final Actor r = this.actorService.editMyData(a1);
		Assert.isTrue(!(comprueba.equals(r.getEmail())));

	}

}
