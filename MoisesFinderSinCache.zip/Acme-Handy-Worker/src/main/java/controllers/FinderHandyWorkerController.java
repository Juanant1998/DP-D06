package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Category;
import domain.Finder;
import domain.FixUpTask;
import domain.Report;
import domain.Warranty;

import repositories.CategoryRepository;
import repositories.WarrantyRepository;
import services.FinderService;

@Controller
@RequestMapping("/finder/handyworker")
public class FinderHandyWorkerController extends AbstractController {
	@Autowired
	private FinderService finderService;
	@Autowired
	private WarrantyRepository warrantyRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	public FinderHandyWorkerController() {
		super();
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Finder finder;
		// cambio de warrantyService.create() a
		finder = this.finderService.create();
		result = this.createEditModelAndView(finder);
		return result;

	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "search")
	public ModelAndView save(@Valid Finder finder, BindingResult binding) {
		ModelAndView result;

		// ES NECESARIO ENCONTRAR TODAS LAS QUE NO TENGAN UNA ACEPTADA????

		Finder sq = this.finderService.allFilters(finder);

		final Collection<FixUpTask> col = sq.getFixUpTasks();
		result = new ModelAndView("fixuptask/list");

		result.addObject("fixuptasks", col);

		result.addObject("requestURI", "/fixuptask/handyworker/list.do");

		if (binding.hasErrors()) {
			result = createEditModelAndView(finder);
			System.out.println("error de mierda");
		} else {

			try {
				this.finderService.save(sq);
			} catch (Throwable oops) {
				result = createEditModelAndView(finder, "finder.commit.error");
			}

			
		}
		return result;
	}

	protected ModelAndView createEditModelAndView(final Finder f) {
		ModelAndView result;
		result = this.createEditModelAndView(f, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Finder f,
			final String messageCode) {
		ModelAndView result;
		Collection<Finder> finderlist;
		final List<Warranty> warN = new ArrayList<>();
		final List<Category> catN = new ArrayList<>();

		for (Warranty w : this.warrantyRepository.findAll()) {
			warN.add(w);
		}

		for (Category ca : this.categoryRepository.findAll()) {
			catN.add(ca);
		}

		finderlist = this.finderService.findAll();
		if (finderlist.contains(f))
			finderlist.remove(f);

		result = new ModelAndView("finder/edit");
		result.addObject("finder", f);
		result.addObject("list", finderlist);
		result.addObject("WarN", warN);
		result.addObject("CatN", catN);

		result.addObject("message", messageCode);

		return result;
	}

}
