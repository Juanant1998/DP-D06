package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CategoryRepository;
import repositories.FinderRepository;
import repositories.FixUpTaskRepository;
import repositories.WarrantyRepository;
import domain.Category;
import domain.Finder;
import domain.FixUpTask;
import domain.Warranty;

@Service
@Transactional
public class FinderService {

	@Autowired
	private FinderRepository finderRepository;
	@Autowired
	private CategoryRepository categoryRepository;
	@Autowired
	private WarrantyRepository warrantyRepository;
	@Autowired
	private FixUpTaskRepository fixUpTaskRepository;

	public Finder create() {

		return new Finder();
	}

	public Collection<Finder> findAll() {
		return this.finderRepository.findAll();
	}

	public Finder findOne(final int finderId) {
		return this.finderRepository.findOne(finderId);
	}

	public Finder save(final Finder finder) {
		return this.finderRepository.save(finder);
	}

	public void delete(final Finder finder) {
		this.finderRepository.delete(finder);
	}

	public Finder allFilters(Finder finder) {

		/*
		 * final Collection<FixUpTask> q =
		 * this.finderRepository.filterTasksWithKeyword(keyword); final
		 * Collection<FixUpTask> d =
		 * this.finderRepository.filterTasksWithDateRange(start, end); final
		 * Collection<FixUpTask> p =
		 * this.finderRepository.filterTasksWithPriceRange(min, max); final
		 * Collection<FixUpTask> w =
		 * finderRepository.filterTasksWithWarranty(warranty); final
		 * Collection<FixUpTask>c =
		 * finderRepository.filterTasksWithCategory(category);
		 */
		Assert.notNull(finder);

		final Collection<FixUpTask> fix = this.fixUpTaskRepository.findAll();

		if (finder.getQuery() !=null && finder.getQuery()!="") {
			System.out.println("1");
			final Collection<FixUpTask> q =
					  this.finderRepository.filterTasksWithKeyword(finder.getQuery());
			fix.retainAll(q);
			
	
		if (finder.getStartDate() !=null && finder.getEndDate()!=null ) {
			System.out.println("2");
			final Collection<FixUpTask> d = this.finderRepository.filterTasksWithDateRange(finder.getStartDate(), finder.getEndDate());
			fix.retainAll(d);
			
		}
		if (finder.getMinPrice() !=null && finder.getMaxPrice()!=null) {
			System.out.println("3");
			final Collection<FixUpTask> p = this.finderRepository.filterTasksWithPriceRange(finder.getMinPrice(), finder.getMaxPrice());
			fix.retainAll(p);
			
		}
		if (finder.getCategory() !=null ) {
			System.out.println("4");
			final Collection<FixUpTask>c = finderRepository.filterTasksWithCategory(finder.getCategory());
			fix.retainAll(c);
			
		}
		if (finder.getWarranty() !=null ) {
			System.out.println("5");
			final  Collection<FixUpTask> w =finderRepository.filterTasksWithWarranty(finder.getWarranty());
			fix.retainAll(w);
			
		}else{
			System.out.println(fix);
		}
		}
		System.out.println("final");

		finder.setFixUpTasks(fix);
      
		return finder;
	}
}
