import java.util.ArrayList;
import java.util.List;


public class PruebaConjuntos {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer>  uno = new ArrayList<>();
		List<Integer>  dos  = new ArrayList<>();
		List<Integer>  tres = new ArrayList<>();
tres.add(1);
tres.add(2);
tres.add(3);
tres.add(4);

dos.add(1);
dos.add(8);
dos.add(3);
dos.add(4);


uno.add(1);
uno.add(2);
uno.add(3);
uno.add(7);

System.out.println(uno.retainAll(dos));

uno.retainAll(tres);
System.out.println(uno);
	}

}
