package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


import domain.Warranty;


import repositories.WarrantyRepository;

@Component
@Transactional
public class StringToWarrantyConverter implements Converter<String,Warranty> {
	@Autowired
	WarrantyRepository	cp;
	
	
	@Override
	public Warranty convert(final String text) {
		Warranty result;
		 int id;
	
		 
		 try {
				if (StringUtils.isEmpty(text))
					result = null;
				else {
					id = Integer.valueOf(text);
					result = this.cp.findOne(id);
				}
			} catch (final Throwable oops) {
				throw new IllegalArgumentException(oops);
			}
			return result;

		}
}
