package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import repositories.FixUpTaskRepository;
import domain.FixUpTask;

@Service
@Transactional
public class FixUpTaskService {

	@Autowired
	private FixUpTaskRepository fixUpTaskRepository; 
	@Autowired
	private SystemConfigService  scs;
	
	public FixUpTask create(){
		return new FixUpTask();
	}
	public Collection<FixUpTask> findAll(){
		return fixUpTaskRepository.findAll();
	}
	public FixUpTask findOne(int fixUpTaskId){
		return fixUpTaskRepository.findOne(fixUpTaskId);
	}
	public FixUpTask save(FixUpTask fixUpTask){
		return fixUpTaskRepository.save(fixUpTask);
	}
	public void delete(FixUpTask fixUpTask){
		fixUpTaskRepository.delete(fixUpTask);
	}
	public Map<String,Double> ivaCalculate(Collection<FixUpTask> listaFix){
	
		Map<String,Double> result = new HashMap<String, Double>();
		
		for (FixUpTask fixUp : listaFix){
		 Double precio = fixUp.getMaximumPrice();
		 Double calculate = precio * (1+ this.scs.getSystemConfig().getVat());
		
		 
		 String  precioIva = "("+Double.toString(calculate)+")";
		 result.put(precioIva, precio);
			 
	 }
	return result;
	
	}
}
