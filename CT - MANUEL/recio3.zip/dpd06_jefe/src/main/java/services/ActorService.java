
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ActorRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Message;
import domain.MessageBox;
import domain.Profile;
import domain.SystemConfig;

@Service
@Transactional
public class ActorService {

	@Autowired
	private ActorRepository		actorRepository;

	@Autowired
	private MessageBoxService	mbs;

	@Autowired
	private MessageService		ms;


	public Actor create() {
		return new Actor();
	}
	public Collection<Actor> findAll() {
		return this.actorRepository.findAll();
	}
	public Actor findOne(final int actorId) {
		return this.actorRepository.findOne(actorId);
	}
	public Actor save(final Actor actor) {
		return this.actorRepository.save(actor);
	}
	public void delete(final Actor actor) {
		this.actorRepository.delete(actor);
	}

	public boolean isActualActorBanned() {

		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);

		return a.getIsBanned();

	}

	public MessageBox createNewMessageBox(final String username, final String msgboxname) {
		final MessageBox msgbox = this.mbs.create();
		msgbox.setName(msgboxname);
		msgbox.setSystemBox(true);

		final MessageBox result = msgbox;

		return result;
	}

	public Actor editMyData(final Actor a1) {

		Assert.notNull(a1);

		final Actor a2 = this.create();
		a2.setAddress(a1.getAddress());
		a2.setEmail(a1.getEmail());
		a2.setMiddleName(a1.getMiddleName());
		a2.setName(a1.getName());
		a2.setPhone(a1.getPhone());
		a2.setPhoto(a1.getPhoto());
		a2.setProfiles(new ArrayList<Profile>());
		a2.setIsSuspicious(a1.getIsSuspicious());
		a2.setIsBanned(a1.getIsBanned());

		a2.setMessageBoxes(a1.getMessageBoxes());
		final Actor x = this.save(a2);

		return x;

	}

	public Collection<MessageBox> getMyBoxes() {
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);
		return a.getMessageBoxes();
	}

	public Collection<Message> messagesByMessageBoxName(final String boxName) {
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);
		final Collection<MessageBox> mBoxes = a.getMessageBoxes();
		final Collection<Message> res = new ArrayList<>();

		for (final MessageBox mbox : mBoxes)
			if (mbox.getName().equals(boxName))
				for (final Message msg : mbox.getMessages())
					res.add(msg);
		return res;
	}

	public Message sendMessage(final Message msg) {
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);
		Assert.notNull(msg);
		Assert.isTrue(!a.getIsBanned());

		final Message result = this.ms.save(msg);

		final Collection<MessageBox> aboxes = a.getMessageBoxes();
		for (final MessageBox abox : aboxes)
			if (abox.getName().endsWith("out box") && abox.isSystemBox() == true) {
				final Collection<Message> ames = abox.getMessages();
				ames.add(result);
				abox.setMessages(ames);

			}

		final Collection<Actor> recipients = result.getRecipients();
		for (final Actor r : recipients) {
			final Collection<MessageBox> rboxes = r.getMessageBoxes();
			for (final MessageBox rbox : rboxes)
				if (this.checkSpammer(result.getBody()) == true || this.checkSpammer(result.getSubject()) == true || this.checkSpammer(result.getTags()) == true) {
					if (rbox.getName().endsWith("spam box") && rbox.isSystemBox() == true) {
						final Collection<Message> rmes = rbox.getMessages();
						rmes.add(result);
						rbox.setMessages(rmes);

					}
				} else if (rbox.getName().endsWith("in box") && rbox.isSystemBox() == true) {
					final Collection<Message> rmes = rbox.getMessages();
					rmes.add(result);
					rbox.setMessages(rmes);

				}
		}
		System.out.println();
		System.out.println("Lo guarda");
		return result;
	}

	private void storeMessageOnSpamBox(final Message m, final Actor a) {
		Assert.notNull(a);
		Assert.notNull(m);
		final Collection<MessageBox> msgboxes = a.getMessageBoxes();

		for (final MessageBox mbox : msgboxes)
			if (mbox.isSystemBox() == true && mbox.getName().endsWith("spam box")) {
				final Collection<Message> messages = mbox.getMessages();
				messages.add(m);
				mbox.setMessages(messages);
				Assert.notNull(mbox);

			}
	}

	private void storeMessageOnOutBox(final Message m, final Actor a) {
		Assert.notNull(a);
		Assert.notNull(m);
		final Collection<MessageBox> msgboxes = a.getMessageBoxes();

		for (final MessageBox mbox : msgboxes)
			if (mbox.isSystemBox() == true && mbox.getName().endsWith("out box")) {
				final Collection<Message> messages = mbox.getMessages();
				messages.add(m);
				mbox.setMessages(messages);
				Assert.notNull(mbox);
				this.mbs.save(mbox);

			}

	}

	public void deleteMessage(final Message m) {
		Assert.notNull(m);
		Assert.isTrue(!(m.getId() == 0));
		final UserAccount actual = LoginService.getPrincipal();
		final Actor actorActual = this.actorRepository.getActor(actual);
		Assert.isTrue(!actorActual.getIsBanned());

		final List<MessageBox> msgb = (List<MessageBox>) actorActual.getMessageBoxes();
		final MessageBox trash = msgb.get(2);
		if (trash.getMessages().contains(m)) {
			final Collection<Message> mess = trash.getMessages();
			mess.remove(m);
			trash.setMessages(mess);
			this.mbs.save(trash);

			Boolean bBorrar = true;
			final Collection<Actor> actores = this.findAll();
			actores.remove(actorActual);
			for (final Actor a : actores) {
				for (final MessageBox mboxes : a.getMessageBoxes()) {
					for (final Message mes : mboxes.getMessages())
						if (mes.getId() == m.getId()) {
							bBorrar = false;
							break;
						}

					if (!bBorrar)
						break;
				}
				if (!bBorrar)
					break;
			}
			if (bBorrar) {
				this.ms.delete(m);
				return;
			}
		}
		for (int i = 0; i < msgb.size(); i++)
			if (msgb.get(i).getMessages().contains(m)) {
				final MessageBox boxm = msgb.get(i);

				if (!boxm.getName().endsWith("trash box")) {
					final Collection<Message> mthere = boxm.getMessages();
					mthere.remove(m);
					boxm.setMessages(mthere);
					this.mbs.save(boxm);

					final MessageBox trashDestino = msgb.get(2);
					final Collection<Message> tmessages = trashDestino.getMessages();
					tmessages.add(m);
					trashDestino.setMessages(tmessages);
					this.mbs.save(trashDestino);
				}
			}
	}

	private void storeMessageOnTrashBox(final Message m, final Actor a) {
		Assert.notNull(a);
		Assert.notNull(m);
		final Collection<MessageBox> msgboxes = a.getMessageBoxes();

		for (final MessageBox mbox : msgboxes)
			if (mbox.isSystemBox() == true && mbox.getName().endsWith("trash box")) {
				final Collection<Message> messages = mbox.getMessages();
				messages.add(m);
				mbox.setMessages(messages);
				Assert.notNull(mbox);

			}
	}

	public MessageBox editMessageBox(final MessageBox m) {
		// Otra opci�n es editar el nombre desde el m.getName.
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.actorRepository.getActor(actual);

		Assert.isTrue(!a.getIsBanned());

		Assert.isTrue(!m.isSystemBox());

		final MessageBox result = this.mbs.save(m);

		return result;

	}

	public void deleteMessageBox(final MessageBox m) {
		final UserAccount actual = LoginService.getPrincipal();
		// COMPROBAR si es el due�o de la message box
		final Actor a = this.actorRepository.getActor(actual);

		Assert.isTrue(a.getMessageBoxes().contains(m));
		Assert.isTrue(!a.getIsBanned());

		Assert.isTrue(!m.isSystemBox());
		final Collection<MessageBox> actorBoxes = a.getMessageBoxes();
		actorBoxes.remove(m);
		a.setMessageBoxes(actorBoxes);
		this.mbs.delete(m);

	}

	public boolean checkSpammer(final String s) {
		final List<String> spamwords = SystemConfig.staticgetSpamWords();
		boolean res = false; // devolvemos esta propiedad para hacer m�s f�cil
								// el env�o de mensajes.
		for (final String spamword : spamwords)
			if (s.contains(spamword)) {
				final UserAccount actual = LoginService.getPrincipal();
				final Actor a = this.actorRepository.getActor(actual);
				a.setIsSuspicious(true);
				res = true;
			}

		return res;
	}

	private void storeMessageOnInBox(final Message m, final Actor a) {
		Assert.notNull(a);
		Assert.notNull(m);
		final Collection<MessageBox> msgboxes = a.getMessageBoxes();

		for (final MessageBox mbox : msgboxes)
			if (mbox.isSystemBox() == true && mbox.getName().endsWith("in box")) {
				final Collection<Message> messages = mbox.getMessages();
				messages.add(m);
				mbox.setMessages(messages);
				Assert.notNull(mbox);
				final MessageBox messagenew = this.mbs.save(mbox);

			}

		// Guardar de nuevo el actor con la nueva lista de mensajes?
	}

	/*
	 * public void storeMessageOnCustomBox(Message m, MessageBox mbox) {
	 * final UserAccount actual = LoginService.getPrincipal();
	 * final Actor a = this.actorRepository.getActor(actual);
	 * Collection<MessageBox> actorBoxes = a.getMessageBoxes();
	 * Assert.isTrue(actorBoxes.contains(mbox));
	 * 
	 * Assert.isTrue(!a.getIsBanned());
	 * 
	 * Assert.isTrue(!mbox.isSystemBox());
	 * 
	 * Collection<Message> messages = mbox.getMessages();
	 * 
	 * Assert.isTrue(expression)
	 * messages.add(m);
	 * mbox.setMessages(messages);
	 * this.mbs.save(mbox);
	 * 
	 * }
	 */

}
