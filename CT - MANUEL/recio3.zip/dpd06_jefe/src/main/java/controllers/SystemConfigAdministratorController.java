package controllers;

import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



import domain.SystemConfig;

import services.SystemConfigService;

@Controller
@RequestMapping("/systemconfig/administrator")
public class SystemConfigAdministratorController {
	
	@Autowired
	private SystemConfigService SCService;
	
	
	
	@RequestMapping(value="/edit", method=RequestMethod.GET)
	public ModelAndView edit(){
		ModelAndView result;
		SystemConfig systemConfig;
		
		systemConfig = SCService.getSystemConfig();
		
        Assert.notNull(systemConfig);
		
		result = this.createEditModelAndView(systemConfig);
		
		return result;
	}
	
	
	@RequestMapping(value="/edit", method=RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final SystemConfig systemConfig, final BindingResult binding){
		ModelAndView result;
		
		if(binding.hasErrors()){
			result = this.createEditModelAndView(systemConfig);
		} else{
			try {
				this.SCService.save(systemConfig);
				result = new ModelAndView("redirect:edit.do"); //edit.do???
			} catch (final Throwable oops){
				result = this.createEditModelAndView(systemConfig, "systemconfig.commit.error");
			}
		}
		
		
		
		return result;
	}
	

	protected ModelAndView createEditModelAndView(SystemConfig systemConfig) {
	    ModelAndView result;
	    
	    result = createEditModelAndView(systemConfig, null);
	    
		return result;
	}
	
	protected ModelAndView createEditModelAndView(SystemConfig systemConfig, String messageCode) {
		ModelAndView result;

	
		result = new ModelAndView("systemconfig/edit");
		result.addObject("systemConfig", systemConfig);
		result.addObject("message", messageCode);

		return result;
	}

}
