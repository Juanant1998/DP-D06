package converters;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import domain.SystemConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;

import repositories.SystemConfigRepository;
@Component
@Transactional
public class StringToSystemConfigConverter implements Converter<String, SystemConfig>{
	
	@Autowired
	SystemConfigRepository systemConfigRepository;
	
	
	@Override
	public SystemConfig convert(String text){
		SystemConfig result;
		int id;
		
		try {
			if (StringUtils.isEmpty(text)){
				result = null;
			}else{
				id = Integer.valueOf(text);
				result = this.systemConfigRepository.findOne(id);
			}
		} catch (Throwable oops){
			throw new IllegalArgumentException(oops);
			
		}
		
		return result;
	}

}
