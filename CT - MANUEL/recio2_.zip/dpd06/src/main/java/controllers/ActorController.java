package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import security.Authority;
import services.ActorService;
import services.AdministratorService;
import services.CustomerService;
import services.HandyWorkerService;
import services.RefereeService;
import services.SponsorService;

import controllers.AbstractController;
import domain.Actor;
import domain.Administrator;
import domain.Customer;
import domain.HandyWorker;
import domain.Referee;
import domain.Sponsor;

@Controller
@RequestMapping("/actor")
public class ActorController extends AbstractController{
	
	@Autowired
	private ActorService actorService;
	
	@Autowired
	private HandyWorkerService hws;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private SponsorService sponsorService;
	
	@Autowired
	private AdministratorService adminService;
	
	@Autowired
	private RefereeService refereeService;
	
	
	
	
	@RequestMapping(value="/create", method=RequestMethod.GET)
	public ModelAndView create(){
		ModelAndView result;
		Actor actor;
		
		actor = this.actorService.create();
		result = this.createEditModelAndView(actor);
		
		return result;
	}
	
	@RequestMapping(value="/edit", method=RequestMethod.GET)
	public ModelAndView edit(@RequestParam int actorId){
		ModelAndView result;
		Actor actor;
		
		actor = actorService.findOne(actorId);
		Assert.notNull(actor);
		
		result = this.createEditModelAndView(actor);
		
		return result;
	}
	
	@RequestMapping(value="/edit", method=RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Actor actor, BindingResult binding){
		ModelAndView result = null;
		
		//Authorities:
		Authority admin = new Authority();
		admin.setAuthority(Authority.ADMIN);
		
		Authority referee = new Authority();
		referee.setAuthority(Authority.REFEREE);
		
		Authority customer = new Authority();
		customer.setAuthority(Authority.CUSTOMER);
		
		Authority hw = new Authority();
		hw.setAuthority(Authority.HANDYWORKER);
		
		Authority sponsor = new Authority();
		sponsor.setAuthority(Authority.SPONSOR);
		
		
		if(binding.hasErrors()){
			result = this.createEditModelAndView(actor);
		} else{
			try {
				if(actor.getUserAccount().getAuthorities().contains(admin)){
					this.adminService.save((Administrator) actor);
					result = new ModelAndView("redirect:login.do");
				}
				
				else if(actor.getUserAccount().getAuthorities().contains(hw)){
					this.hws.save((HandyWorker) actor);
					result = new ModelAndView("redirect:login.do");
				}
				
				else if(actor.getUserAccount().getAuthorities().contains(sponsor)){
					this.sponsorService.save((Sponsor) actor);
					result = new ModelAndView("redirect:login.do");
				}
				
				else if(actor.getUserAccount().getAuthorities().contains(customer)){
					this.customerService.register(actor);
					result = new ModelAndView("redirect:login.do");
				}
				
				else if(actor.getUserAccount().getAuthorities().contains(referee)){
					this.refereeService.save((Referee) actor);
					result = new ModelAndView("redirect:login.do");
				}
				
			} catch(Throwable oops){
				result = this.createEditModelAndView(actor, "actor.commit.error");
			}
		}
		
		return result;
	}
	
	
	
	

	protected ModelAndView createEditModelAndView(Actor actor) {
        ModelAndView result;
		
		result = this.createEditModelAndView(actor, null);
		
		return result;
	}
	
	protected ModelAndView createEditModelAndView(Actor actor, String messageCode) {
		ModelAndView result;
		Collection<Authority> authorities = new ArrayList<Authority>();
		Authority admin = new Authority();
		admin.setAuthority(Authority.ADMIN);
		
		Authority referee = new Authority();
		referee.setAuthority(Authority.REFEREE);
		
		authorities = Authority.listAuthorities();
		authorities.remove(admin);
		authorities.remove(referee);
		
		
		
		result = new ModelAndView("actor/edit");
		result.addObject("actor", actor);
		
		
		result.addObject("message", messageCode);
		
		return result;
	}

}
