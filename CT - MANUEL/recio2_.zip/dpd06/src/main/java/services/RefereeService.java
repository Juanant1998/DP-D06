package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import repositories.RefereeRepository;
import security.Authority;
import security.UserAccount;


import domain.MessageBox;
import domain.Profile;
import domain.Referee;

@Service
@Transactional
public class RefereeService {
	
	@Autowired
	private RefereeRepository refereeRepository;
	
	@Autowired
	private ActorService actorservice;
	
	@Autowired
	private UserAccountService uaS;
	
	@Autowired
	private ProfileService ps;
	
	public Referee create(){
		Referee c = new Referee();
		
		
		final MessageBox in = this.actorservice.createNewMessageBox("ususario", "-in");
		final MessageBox out = this.actorservice.createNewMessageBox("ususario", "-out");
		final MessageBox trash = this.actorservice.createNewMessageBox("ususario", "-trash");
		final MessageBox spam = this.actorservice.createNewMessageBox("ususario", "-spam");

		final Collection<MessageBox> msboxes = new ArrayList<MessageBox>();
		msboxes.add(in);
		msboxes.add(out);
		msboxes.add(trash);
		msboxes.add(spam);

		c.setMessageBoxes(msboxes);
		
        Collection<Authority> authorities = new ArrayList<Authority>();
		Authority cust = new Authority();
        cust.setAuthority(Authority.REFEREE);
	    authorities.add(cust);
	    
		
		UserAccount ua = new UserAccount();
		ua.setUsername(null);
		ua.setPassword(null);
		ua.setAuthorities(authorities);
		
		c.setUserAccount(ua);
		
		c.setIsBanned(false);
		c.setIsSuspicious(false);
		
		return c;
	}
	public Collection<Referee> findAll(){
		return refereeRepository.findAll();
	}
	
	public Referee findOne(int refereeId){
		return refereeRepository.findOne(refereeId);
	}
	
	public Referee save(Referee referee){
		if(referee.getUserAccount().getId()==0){
			UserAccount ua = this.uaS.save(referee.getUserAccount());
			referee.setUserAccount(ua);
		}
		Collection<Profile> newProfileList = new ArrayList<Profile>();
		Profile nuevo;
		Collection<Profile> perfiles = referee.getProfiles();
		for(Profile f : perfiles){
			if(f.getId() == 0){
					nuevo = this.ps.save(f);
					
				
			} else {
					nuevo = f;
			}				newProfileList.add(nuevo);

		}
		referee.setProfiles(newProfileList);
		
		Md5PasswordEncoder encoder;
		encoder = new Md5PasswordEncoder();
		String hash;
		hash = encoder.encodePassword(referee.getUserAccount().getPassword(), null);
		referee.getUserAccount().setPassword(hash);
		System.out.println(referee.getUserAccount().getPassword());
		
		
		return refereeRepository.save(referee);
	}
	
	public void delete(Referee referee){
		refereeRepository.delete(referee);
	}

}
