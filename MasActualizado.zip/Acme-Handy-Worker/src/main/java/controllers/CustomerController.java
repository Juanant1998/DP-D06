/*
 * CustomerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.ActorService;
import services.CustomerService;
import services.FixUpTaskService;
import services.MessageBoxService;
import services.SystemConfigService;
import domain.Customer;
import domain.FixUpTask;

@Controller
@RequestMapping("/customer")
public class CustomerController extends AbstractController {

	@Autowired
	private SystemConfigService		scs;
	@Autowired
	private ActorService			actorservice;
	@Autowired
	private CustomerService			cs;

	@Autowired
	private UserAccountRepository	userAccountRepository;

	@Autowired
	private FixUpTaskService		futs;

	@Autowired
	private MessageBoxService		mbs;


	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create")
	public ModelAndView create() {
		ModelAndView result;
		Customer customer;

		customer = this.cs.create();
		result = this.createEditModelAndView(customer);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Customer customer;

		final UserAccount uA = LoginService.getPrincipal();
		customer = this.userAccountRepository.getCustomerByUserAccount(uA.getUsername());
		Assert.notNull(customer);

		result = this.createEditModelAndView(customer);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	// Save ---------------------------------------------------------------	

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Customer customer, final BindingResult binding) {
		ModelAndView result;
		System.out.println(customer.getAddress());
		System.out.println(customer.getId());

		final Collection<Authority> authorities = new ArrayList<Authority>();

		final Authority cust = new Authority();
		//System.out.println(cust);
		cust.setAuthority(Authority.CUSTOMER);

		authorities.add(cust);
		//System.out.println(authorities);
		customer.getUserAccount().setAuthorities(authorities);
		System.out.println(customer.getUserAccount().getAuthorities());

		System.out.println(customer.getFixUpTasks());
		System.out.println(customer.getEmail());
		System.out.println(customer.getMessageBoxes());

		System.out.println(customer.getProfiles());
		System.out.println(customer.getAddress());

		System.out.println("antes del if");
		if (binding.hasErrors()) {
			System.out.println("binding");
			result = this.createEditModelAndView(customer);
			System.out.println("despues del editmodelandview");
		} else
			try {
				System.out.println("try");
				this.cs.save(customer);
				result = new ModelAndView("redirect:/welcome/index.do");
				System.out.println(customer.getUserAccount().getPassword());

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(customer, "customer.commit.error");
			}

		return result;
	}

	protected ModelAndView createEditModelAndView(final Customer customer) {
		ModelAndView result;

		result = this.createEditModelAndView(customer, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Customer customer, final String messageCode) {
		ModelAndView result;

		System.out.println(customer.getUserAccount().getPassword());

		result = new ModelAndView("customer/edit");
		result.addObject("customer", customer);

		result.addObject("message", messageCode);

		return result;
	}

	@RequestMapping("/display")
	public ModelAndView display(@RequestParam final int futId) {
		ModelAndView result;

		final FixUpTask f = this.futs.findOne(futId);
		final Customer c = this.cs.findCustomerByFixUpTask(f);

		result = this.createDisplayModelAndView(c);

		return result;

	}

	protected ModelAndView createDisplayModelAndView(final Customer c) {
		ModelAndView result;
		result = this.createDisplayModelAndView(c, null);

		return result;
	}

	protected ModelAndView createDisplayModelAndView(final Customer c, final String messageCode) {
		ModelAndView result;
		result = new ModelAndView("customer/display");
		result.addObject("customer", c);

		result.addObject("message", messageCode);

		return result;

	}
}
