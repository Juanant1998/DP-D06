
package services;

import java.util.Collection;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CategoryRepository;
import domain.Category;

@Service
@Transactional
public class CategoryService {

	@Autowired
	private CategoryRepository	categoryRepository;


	public Category create() {
		return new Category();
	}
	public Collection<Category> findAll() {
		return this.categoryRepository.findAll();
	}
	public Category findOne(final int categoryId) {
		return this.categoryRepository.findOne(categoryId);
	}
	public Category save(final Category category) {
		return this.categoryRepository.save(category);
	}
	public void delete(final Category category) {
		
		Assert.isTrue(category.getId()!=0);
		final Collection<Category> categories = this.categoryRepository.findAll();

		for (final Category c : categories){
			
			Collection<Category> des = c.getDescendants();
			if (c.getDescendants().contains(category))
			
			des.remove(category);
			c.setDescendants(des);
			
			
		this.categoryRepository.delete(category);
	}

	}
}
