
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import repositories.WarrantyRepository;
import domain.Finder;
import domain.Warranty;

@Service
@Transactional
public class WarrantyService {

	@Autowired
	private WarrantyRepository	warrantyRepository;
	@Autowired
	private FinderService finderService;


	public Warranty create() {
		return new Warranty();
	}

	public Collection<Warranty> findAll() {
		return this.warrantyRepository.findAll();
	}

	public Warranty findOne(final int warrantyId) {
		return this.warrantyRepository.findOne(warrantyId);
	}

	public Warranty save(final Warranty warranty) {
		return this.warrantyRepository.save(warranty);
	}

	public void delete(final Warranty warranty) {
		List<Finder> finds = (List<Finder>) this.finderService.findAll();
		for(Finder f : finds){
			 if (f.getWarranty().equals(warranty)){
				 Warranty n = new Warranty();
				 f.setWarranty(n); 
			 }
		}
		this.warrantyRepository.delete(warranty);
	}

	public Collection<Warranty> findAllFinalMode() {
		final Collection<Warranty> warranties = this.warrantyRepository.findAll();
		final Collection<Warranty> result = new ArrayList<Warranty>();
		for (final Warranty x : warranties)
			if (x.isDraftMode() == false)
				result.add(x);

		return warranties;
	}

}
